import os
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

from app.models.database import init_db, get_db, SessionLocal
from app.services.seed_data import seed_database
from app.api import admin, org, messages, students, auth

app = FastAPI(title="Internship Community Matching API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000", "http://127.0.0.1:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
UPLOADS_DIR = os.path.join(BASE_DIR, "uploads")
os.makedirs(UPLOADS_DIR, exist_ok=True)

app.mount("/uploads", StaticFiles(directory=UPLOADS_DIR), name="uploads")

app.include_router(auth.router)
app.include_router(admin.router)
app.include_router(org.router)
app.include_router(messages.router)
app.include_router(students.router)


@app.on_event("startup")
def on_startup():
    init_db()
    db = SessionLocal()
    try:
        result = seed_database(db)
        print(f"[startup] {result}")
    finally:
        db.close()


@app.get("/")
def root():
    return {"status": "ok", "message": "Internship Community Matching API is running"}


@app.get("/api/health")
def health():
    return {"status": "healthy"}
