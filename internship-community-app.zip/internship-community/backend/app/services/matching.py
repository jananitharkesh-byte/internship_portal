def calculate_match_score(student_skills, student_domain, student_dept,
                           req_skills, req_domain, req_dept):
    score = 0.0

    student_skills_list = [s.strip().lower() for s in (student_skills or "").split(",") if s.strip()]
    req_skills_list = [s.strip().lower() for s in (req_skills or "").split(",") if s.strip()]
    skill_overlap = len(set(student_skills_list) & set(req_skills_list))
    skill_ratio = skill_overlap / len(req_skills_list) if req_skills_list else 0
    score += skill_ratio * 60

    if (student_domain or "").strip().lower() == (req_domain or "").strip().lower() and student_domain:
        score += 25

    if (student_dept or "").strip().lower() == (req_dept or "").strip().lower() and student_dept:
        score += 15

    return min(round(score, 2), 100)


def generate_matches_for_student(db, student):
    from app.models.database import OrgRequirement, Match, Organization

    reqs = db.query(OrgRequirement).all()
    created = []
    for req in reqs:
        score = calculate_match_score(
            student.skills, student.domain, student.dept_preference,
            req.required_skills, req.domain, req.dept
        )
        if score >= 40:  # only keep meaningful matches
            existing = db.query(Match).filter(
                Match.student_id == student.id, Match.org_id == req.org_id
            ).first()
            if not existing:
                m = Match(student_id=student.id, org_id=req.org_id, match_score=score)
                db.add(m)
                created.append(m)
    db.commit()
    return created
