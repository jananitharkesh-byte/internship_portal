import os
import zipfile
import shutil
import openpyxl
from app.models.database import Student
from app.services.matching import generate_matches_for_student

BASE_DIR = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
UPLOADS_DIR = os.path.join(BASE_DIR, "uploads")
CV_DIR = os.path.join(UPLOADS_DIR, "cvs")


def process_upload_zip(db, zip_path):
    """
    Expects a ZIP containing:
      - one .xlsx file with columns: name, email, skills, domain, dept_preference, cv_filename
      - a folder of CV files (pdf/txt) referenced by cv_filename
    Returns summary dict.
    """
    os.makedirs(CV_DIR, exist_ok=True)
    extract_dir = os.path.join(UPLOADS_DIR, "_extract_tmp")
    if os.path.exists(extract_dir):
        shutil.rmtree(extract_dir)
    os.makedirs(extract_dir)

    with zipfile.ZipFile(zip_path, "r") as z:
        z.extractall(extract_dir)

    excel_path = None
    cv_files = {}
    for root, _, files in os.walk(extract_dir):
        for fname in files:
            full = os.path.join(root, fname)
            if fname.lower().endswith((".xlsx", ".xls")):
                excel_path = full
            elif fname.lower().endswith(".pdf") or fname.lower().endswith(".txt"):
                cv_files[fname] = full

    if not excel_path:
        raise ValueError("No Excel file found in ZIP")

    wb = openpyxl.load_workbook(excel_path)
    ws = wb.active
    headers = [str(c.value).strip().lower() if c.value else "" for c in ws[1]]

    created_students = []
    for row in ws.iter_rows(min_row=2, values_only=True):
        row_dict = dict(zip(headers, row))
        if not row_dict.get("name"):
            continue

        cv_filename = row_dict.get("cv_filename")
        cv_dest_rel = None
        if cv_filename and cv_filename in cv_files:
            dest_name = f"{len(created_students)}_{cv_filename}"
            dest_path = os.path.join(CV_DIR, dest_name)
            shutil.copy(cv_files[cv_filename], dest_path)
            cv_dest_rel = f"uploads/cvs/{dest_name}"

        student = Student(
            name=str(row_dict.get("name")),
            email=str(row_dict.get("email", "")),
            skills=str(row_dict.get("skills", "")),
            domain=str(row_dict.get("domain", "")),
            dept_preference=str(row_dict.get("dept_preference", "")),
            cv_path=cv_dest_rel,
        )
        db.add(student)
        created_students.append(student)

    db.commit()
    for s in created_students:
        db.refresh(s)
        generate_matches_for_student(db, s)

    shutil.rmtree(extract_dir, ignore_errors=True)

    return {"students_created": len(created_students), "names": [s.name for s in created_students]}
