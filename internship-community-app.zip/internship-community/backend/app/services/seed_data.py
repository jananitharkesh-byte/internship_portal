import random
import os
from app.models.database import Organization, OrgContact, Student, OrgRequirement, Match
from app.services.matching import calculate_match_score

BASE_DIR = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
UPLOADS_DIR = os.path.join(BASE_DIR, "uploads", "cvs")

INDUSTRIES = {
    "Tech": ["Python", "JavaScript", "React", "SQL", "AWS", "Docker", "Node.js", "Java", "Git", "REST APIs"],
    "Finance": ["Excel", "Financial Modeling", "Python", "SQL", "Bloomberg Terminal", "Accounting", "Risk Analysis"],
    "Healthcare": ["Data Analysis", "Python", "Biostatistics", "Excel", "Research", "Clinical Documentation"],
    "Design": ["Figma", "Adobe XD", "UI/UX", "Photoshop", "Illustrator", "Prototyping", "User Research"],
    "Education": ["Curriculum Design", "Public Speaking", "Content Writing", "Research", "Excel"],
    "Manufacturing": ["AutoCAD", "SolidWorks", "Six Sigma", "Supply Chain", "Excel", "Project Management"],
    "Retail": ["Excel", "Customer Service", "Inventory Management", "Marketing", "Sales Analytics"],
    "Consulting": ["PowerPoint", "Excel", "Data Analysis", "Communication", "Project Management", "Research"],
}

DOMAINS = list(INDUSTRIES.keys())
DEPTS = ["Computer Science", "Business", "Design", "Engineering", "Marketing", "Finance", "Data Science"]

FIRST_NAMES = ["Aarav", "Vivaan", "Aditya", "Vihaan", "Arjun", "Sai", "Reyansh", "Krishna", "Ishaan", "Rohan",
               "Ananya", "Diya", "Saanvi", "Aadhya", "Kiara", "Myra", "Priya", "Sneha", "Ritika", "Neha",
               "Karthik", "Meera", "Nikhil", "Pooja", "Rahul", "Sanya", "Tanvi", "Varun", "Yash", "Zara"]
LAST_NAMES = ["Sharma", "Verma", "Gupta", "Reddy", "Iyer", "Nair", "Rao", "Patel", "Singh", "Menon",
              "Kumar", "Joshi", "Chatterjee", "Mehta", "Kapoor", "Desai", "Pillai", "Bhat", "Chopra", "Malhotra"]

ORG_NAME_PARTS = {
    "Tech": ["ByteForge", "CloudNine", "Nimbus", "Quantum", "Codeverse", "Pixelworks", "Datastream", "Synapse Labs"],
    "Finance": ["Capital Bridge", "Ledgerline", "Meridian Finance", "Vault Partners", "Ascent Capital"],
    "Healthcare": ["MediCore", "PulseHealth", "VitalPoint", "CareBridge", "WellSpring Health"],
    "Design": ["Studio Nine", "Formwork", "Blueprint Design Co.", "Palette Collective", "Grid & Grain"],
    "Education": ["LearnForward", "Edunova", "BrightPath Education", "ScholarWorks"],
    "Manufacturing": ["Ironclad Industries", "Precision Works", "Forgeline Manufacturing", "Apex Fabrication"],
    "Retail": ["MarketLoop", "UrbanCart", "Retail Nexus", "ShelfSpace"],
    "Consulting": ["Insight Partners", "Northbridge Consulting", "Vertex Advisory", "ClearPath Consulting"],
}

SUFFIXES = ["Pvt Ltd", "Solutions", "Group", "Technologies", "Inc", "Labs", "Partners", ""]


def _cv_content(name, skills, domain):
    return (
        f"CURRICULUM VITAE\n\nName: {name}\nDomain: {domain}\nSkills: {skills}\n\n"
        f"This is an auto-generated placeholder CV for prototype purposes.\n"
    )


def seed_database(db, force=False):
    if not force and db.query(Organization).count() > 0:
        return {"message": "Database already seeded"}

    os.makedirs(UPLOADS_DIR, exist_ok=True)

    # --- Organizations ---
    orgs = []
    org_counter = 0
    while len(orgs) < 60:
        industry = DOMAINS[org_counter % len(DOMAINS)]
        base_names = ORG_NAME_PARTS[industry]
        name = f"{random.choice(base_names)} {random.choice(SUFFIXES)}".strip()
        name = f"{name} #{org_counter+1}" if any(o.name.startswith(name) for o in orgs) else name
        org = Organization(
            name=name,
            industry=industry,
            domain=industry,
            description=f"{name} is a {industry.lower()} organization offering internship opportunities in {industry.lower()}-focused roles.",
        )
        db.add(org)
        orgs.append(org)
        org_counter += 1
    db.commit()
    for o in orgs:
        db.refresh(o)

    # --- Org contacts ---
    for org in orgs:
        num_contacts = random.choice([1, 1, 2])
        for i in range(num_contacts):
            fname, lname = random.choice(FIRST_NAMES), random.choice(LAST_NAMES)
            contact = OrgContact(
                org_id=org.id,
                name=f"{fname} {lname}",
                email=f"{fname.lower()}.{lname.lower()}@{org.name.split()[0].lower()}.com",
                phone=f"+91 9{random.randint(100000000, 999999999)}",
                role=random.choice(["HR Manager", "Talent Acquisition Lead", "Internship Coordinator", "HR Executive"]),
                password="password123",
            )
            db.add(contact)

    # --- Org requirements ---
    for org in orgs:
        skill_pool = INDUSTRIES[org.industry]
        req_skills = random.sample(skill_pool, k=min(4, len(skill_pool)))
        req = OrgRequirement(
            org_id=org.id,
            required_skills=", ".join(req_skills),
            domain=org.industry,
            dept=random.choice(DEPTS),
        )
        db.add(req)
    db.commit()

    # --- Students ---
    students = []
    for i in range(55):
        fname, lname = random.choice(FIRST_NAMES), random.choice(LAST_NAMES)
        domain = random.choice(DOMAINS)
        skill_pool = INDUSTRIES[domain]
        skills = random.sample(skill_pool, k=random.randint(3, 5))
        # sprinkle in a skill from a random other domain for variety
        if random.random() < 0.3:
            other_domain = random.choice([d for d in DOMAINS if d != domain])
            skills.append(random.choice(INDUSTRIES[other_domain]))
        skills_str = ", ".join(skills)
        dept = random.choice(DEPTS)
        name = f"{fname} {lname}"
        email = f"{fname.lower()}.{lname.lower()}{i}@university.edu"

        cv_filename = f"{fname.lower()}_{lname.lower()}_{i}_cv.txt"
        cv_path = os.path.join(UPLOADS_DIR, cv_filename)
        with open(cv_path, "w") as f:
            f.write(_cv_content(name, skills_str, domain))

        student = Student(
            name=name,
            email=email,
            skills=skills_str,
            domain=domain,
            dept_preference=dept,
            cv_path=f"uploads/cvs/{cv_filename}",
        )
        db.add(student)
        students.append(student)
    db.commit()
    for s in students:
        db.refresh(s)

    # --- Matches ---
    reqs = db.query(OrgRequirement).all()
    match_count = 0
    for student in students:
        for req in reqs:
            score = calculate_match_score(
                student.skills, student.domain, student.dept_preference,
                req.required_skills, req.domain, req.dept
            )
            if score >= 40:
                m = Match(student_id=student.id, org_id=req.org_id, match_score=score)
                db.add(m)
                match_count += 1
    db.commit()

    return {
        "message": "Database seeded successfully",
        "organizations": len(orgs),
        "students": len(students),
        "matches": match_count,
    }
