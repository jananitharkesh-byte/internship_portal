def send_match_email(contact_name, contact_email, org_name, matched_students):
    """Logs a formatted 'email' to the console. Swap for SendGrid later."""
    lines = []
    lines.append("=" * 70)
    lines.append("📧  EMAIL SENT (console preview — SendGrid integration pending)")
    lines.append("=" * 70)
    lines.append(f"To: {contact_name} <{contact_email}>")
    lines.append(f"Subject: New Intern Matches for {org_name} ({len(matched_students)} candidates)")
    lines.append("-" * 70)
    lines.append(f"Hi {contact_name},")
    lines.append("")
    lines.append(f"We've found {len(matched_students)} strong candidate matches for {org_name}:")
    lines.append("")
    for s in matched_students:
        lines.append(f"  • {s['name']} — {s['match_score']}% match — Skills: {s['skills']}")
    lines.append("")
    lines.append("Log in to the Organization Portal to view full profiles, download CVs,")
    lines.append("and message candidates directly:")
    lines.append("  http://localhost:3000/login")
    lines.append("")
    lines.append("Best,")
    lines.append("The Internship Community Team")
    lines.append("=" * 70)
    print("\n".join(lines))
    return True
