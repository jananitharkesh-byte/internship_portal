from sqlalchemy import create_engine, Column, Integer, String, Float, DateTime, ForeignKey, Text
from sqlalchemy.orm import declarative_base, sessionmaker, relationship
from datetime import datetime
import os

BASE_DIR = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
DB_PATH = os.path.join(BASE_DIR, "community.db")
DATABASE_URL = f"sqlite:///{DB_PATH}"

engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False})
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()


class Organization(Base):
    __tablename__ = "organizations"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, nullable=False)
    industry = Column(String)
    domain = Column(String)
    description = Column(Text)

    contacts = relationship("OrgContact", back_populates="organization", cascade="all, delete-orphan")
    requirements = relationship("OrgRequirement", back_populates="organization", cascade="all, delete-orphan")
    matches = relationship("Match", back_populates="organization", cascade="all, delete-orphan")


class OrgContact(Base):
    __tablename__ = "org_contacts"
    id = Column(Integer, primary_key=True, index=True)
    org_id = Column(Integer, ForeignKey("organizations.id"))
    name = Column(String, nullable=False)
    email = Column(String, nullable=False)
    phone = Column(String)
    role = Column(String)
    password = Column(String, default="password123")

    organization = relationship("Organization", back_populates="contacts")


class Student(Base):
    __tablename__ = "students"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, nullable=False)
    email = Column(String, nullable=False)
    skills = Column(Text, nullable=False)
    domain = Column(String)
    dept_preference = Column(String)
    cv_path = Column(String)
    uploaded_at = Column(DateTime, default=datetime.utcnow)


class OrgRequirement(Base):
    __tablename__ = "org_requirements"
    id = Column(Integer, primary_key=True, index=True)
    org_id = Column(Integer, ForeignKey("organizations.id"))
    required_skills = Column(Text, nullable=False)
    domain = Column(String)
    dept = Column(String)

    organization = relationship("Organization", back_populates="requirements")


class Match(Base):
    __tablename__ = "matches"
    id = Column(Integer, primary_key=True, index=True)
    student_id = Column(Integer, ForeignKey("students.id"))
    org_id = Column(Integer, ForeignKey("organizations.id"))
    match_score = Column(Float)
    status = Column(String, default="pending")  # pending|sent|accepted|rejected
    sent_at = Column(DateTime, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    organization = relationship("Organization", back_populates="matches")
    student = relationship("Student")
    messages = relationship("Message", back_populates="match", cascade="all, delete-orphan")


class Message(Base):
    __tablename__ = "messages"
    id = Column(Integer, primary_key=True, index=True)
    match_id = Column(Integer, ForeignKey("matches.id"))
    sender_type = Column(String)  # 'org' or 'student'
    content = Column(Text, nullable=False)
    sent_at = Column(DateTime, default=datetime.utcnow)

    match = relationship("Match", back_populates="messages")


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def init_db():
    Base.metadata.create_all(bind=engine)
