from pydantic import BaseModel
from typing import Optional, List
from datetime import datetime


class LoginRequest(BaseModel):
    email: str
    password: str


class OrgContactOut(BaseModel):
    id: int
    name: str
    email: str
    role: Optional[str] = None

    class Config:
        from_attributes = True


class OrganizationOut(BaseModel):
    id: int
    name: str
    industry: Optional[str] = None
    domain: Optional[str] = None
    description: Optional[str] = None

    class Config:
        from_attributes = True


class StudentOut(BaseModel):
    id: int
    name: str
    email: str
    skills: str
    domain: Optional[str] = None
    dept_preference: Optional[str] = None
    cv_path: Optional[str] = None

    class Config:
        from_attributes = True


class MatchOut(BaseModel):
    id: int
    student_id: int
    org_id: int
    match_score: float
    status: str
    student: Optional[StudentOut] = None
    organization: Optional[OrganizationOut] = None

    class Config:
        from_attributes = True


class MatchStatusUpdate(BaseModel):
    status: str  # accepted | rejected


class MessageCreate(BaseModel):
    match_id: int
    sender_type: str
    content: str


class MessageOut(BaseModel):
    id: int
    match_id: int
    sender_type: str
    content: str
    sent_at: datetime

    class Config:
        from_attributes = True


class SendMatchesRequest(BaseModel):
    match_ids: List[int]
