import os
from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import FileResponse
from sqlalchemy.orm import Session
from app.models.database import get_db, Student

router = APIRouter(prefix="/api/students", tags=["students"])
BASE_DIR = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


@router.get("/")
def list_students(db: Session = Depends(get_db)):
    students = db.query(Student).all()
    return [{"id": s.id, "name": s.name, "domain": s.domain, "skills": s.skills} for s in students]


@router.get("/{student_id}")
def get_student(student_id: int, db: Session = Depends(get_db)):
    s = db.query(Student).get(student_id)
    if not s:
        raise HTTPException(status_code=404, detail="Student not found")
    return {
        "id": s.id, "name": s.name, "email": s.email, "skills": s.skills,
        "domain": s.domain, "dept_preference": s.dept_preference, "cv_path": s.cv_path,
    }


@router.get("/{student_id}/cv")
def get_cv(student_id: int, db: Session = Depends(get_db)):
    s = db.query(Student).get(student_id)
    if not s or not s.cv_path:
        raise HTTPException(status_code=404, detail="CV not found")
    full_path = os.path.join(BASE_DIR, s.cv_path)
    if not os.path.exists(full_path):
        raise HTTPException(status_code=404, detail="CV file missing")
    return FileResponse(full_path, filename=os.path.basename(full_path))
