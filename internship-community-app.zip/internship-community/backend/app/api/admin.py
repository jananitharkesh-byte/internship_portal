import os
import shutil
from fastapi import APIRouter, Depends, UploadFile, File, HTTPException
from sqlalchemy.orm import Session
from app.models.database import get_db, Student, Organization, Match, OrgContact
from app.services.file_handler import process_upload_zip
from app.services.email_service import send_match_email
from app.services.seed_data import seed_database
from app.schemas.schemas import SendMatchesRequest

router = APIRouter(prefix="/api/admin", tags=["admin"])

UPLOAD_TMP = "/tmp/community_uploads"
os.makedirs(UPLOAD_TMP, exist_ok=True)


@router.post("/seed")
def reseed(db: Session = Depends(get_db)):
    result = seed_database(db, force=True)
    return result


@router.post("/upload")
async def upload_zip(file: UploadFile = File(...), db: Session = Depends(get_db)):
    if not file.filename.lower().endswith(".zip"):
        raise HTTPException(status_code=400, detail="Please upload a .zip file")

    tmp_path = os.path.join(UPLOAD_TMP, file.filename)
    with open(tmp_path, "wb") as f:
        shutil.copyfileobj(file.file, f)

    try:
        result = process_upload_zip(db, tmp_path)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))
    finally:
        os.remove(tmp_path)

    return result


@router.get("/dashboard")
def dashboard(db: Session = Depends(get_db)):
    total_students = db.query(Student).count()
    total_orgs = db.query(Organization).count()
    total_matches = db.query(Match).count()
    pending = db.query(Match).filter(Match.status == "pending").count()

    buckets = {"high": 0, "medium": 0, "low": 0}
    for (score,) in db.query(Match.match_score).all():
        if score >= 80:
            buckets["high"] += 1
        elif score >= 60:
            buckets["medium"] += 1
        else:
            buckets["low"] += 1

    return {
        "total_students": total_students,
        "total_orgs": total_orgs,
        "total_matches": total_matches,
        "pending_matches": pending,
        "match_distribution": buckets,
    }


@router.get("/students")
def get_students(db: Session = Depends(get_db)):
    students = db.query(Student).all()
    return [
        {
            "id": s.id, "name": s.name, "email": s.email, "skills": s.skills,
            "domain": s.domain, "dept_preference": s.dept_preference, "cv_path": s.cv_path,
        }
        for s in students
    ]


@router.delete("/students/{student_id}")
def delete_student(student_id: int, db: Session = Depends(get_db)):
    student = db.query(Student).get(student_id)
    if not student:
        raise HTTPException(status_code=404, detail="Student not found")
    db.query(Match).filter(Match.student_id == student_id).delete()
    db.delete(student)
    db.commit()
    return {"message": "Student deleted"}


@router.get("/matches")
def get_matches(org_id: int = None, status: str = None, min_score: float = None, db: Session = Depends(get_db)):
    q = db.query(Match)
    if org_id:
        q = q.filter(Match.org_id == org_id)
    if status:
        q = q.filter(Match.status == status)
    if min_score is not None:
        q = q.filter(Match.match_score >= min_score)
    matches = q.order_by(Match.match_score.desc()).all()

    return [
        {
            "id": m.id,
            "match_score": m.match_score,
            "status": m.status,
            "student": {"id": m.student.id, "name": m.student.name, "skills": m.student.skills, "domain": m.student.domain},
            "organization": {"id": m.organization.id, "name": m.organization.name, "industry": m.organization.industry},
        }
        for m in matches
    ]


@router.post("/matches/send")
def send_matches(payload: SendMatchesRequest, db: Session = Depends(get_db)):
    from datetime import datetime

    sent_count = 0
    by_org = {}
    for match_id in payload.match_ids:
        m = db.query(Match).get(match_id)
        if not m:
            continue
        m.status = "sent"
        m.sent_at = datetime.utcnow()
        by_org.setdefault(m.org_id, []).append(m)
        sent_count += 1
    db.commit()

    for org_id, matches in by_org.items():
        org = db.query(Organization).get(org_id)
        contact = db.query(OrgContact).filter(OrgContact.org_id == org_id).first()
        if contact:
            send_match_email(
                contact.name, contact.email, org.name,
                [{"name": m.student.name, "match_score": m.match_score, "skills": m.student.skills} for m in matches],
            )

    return {"sent": sent_count, "organizations_notified": len(by_org)}


@router.put("/matches/{match_id}")
def update_match(match_id: int, status: str, db: Session = Depends(get_db)):
    m = db.query(Match).get(match_id)
    if not m:
        raise HTTPException(status_code=404, detail="Match not found")
    m.status = status
    db.commit()
    return {"message": "Match updated"}
