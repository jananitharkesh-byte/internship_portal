import os
from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import FileResponse
from sqlalchemy.orm import Session
from app.models.database import get_db, Match, Student, Message, Organization

router = APIRouter(prefix="/api/org", tags=["org"])

BASE_DIR = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


@router.get("/dashboard")
def org_dashboard(org_id: int, db: Session = Depends(get_db)):
    org = db.query(Organization).get(org_id)
    if not org:
        raise HTTPException(status_code=404, detail="Organization not found")
    matches = db.query(Match).filter(Match.org_id == org_id).all()
    unread = 0
    for m in matches:
        unread += db.query(Message).filter(Message.match_id == m.id, Message.sender_type == "student").count()
    return {
        "org_name": org.name,
        "matched_students": len(matches),
        "accepted": len([m for m in matches if m.status == "accepted"]),
        "pending": len([m for m in matches if m.status in ("pending", "sent")]),
        "messages_count": unread,
    }


@router.get("/matches")
def org_matches(org_id: int, db: Session = Depends(get_db)):
    matches = db.query(Match).filter(Match.org_id == org_id).order_by(Match.match_score.desc()).all()
    return [
        {
            "id": m.id,
            "match_score": m.match_score,
            "status": m.status,
            "student": {
                "id": m.student.id, "name": m.student.name, "email": m.student.email,
                "skills": m.student.skills, "domain": m.student.domain,
                "dept_preference": m.student.dept_preference, "cv_path": m.student.cv_path,
            },
        }
        for m in matches
    ]


@router.put("/matches/{match_id}/status")
def update_match_status(match_id: int, status: str, db: Session = Depends(get_db)):
    m = db.query(Match).get(match_id)
    if not m:
        raise HTTPException(status_code=404, detail="Match not found")
    if status not in ("accepted", "rejected", "pending", "sent"):
        raise HTTPException(status_code=400, detail="Invalid status")
    m.status = status
    db.commit()
    return {"message": "Status updated", "status": status}


@router.get("/students/{student_id}/cv")
def download_cv(student_id: int, db: Session = Depends(get_db)):
    student = db.query(Student).get(student_id)
    if not student or not student.cv_path:
        raise HTTPException(status_code=404, detail="CV not found")
    full_path = os.path.join(BASE_DIR, student.cv_path)
    if not os.path.exists(full_path):
        raise HTTPException(status_code=404, detail="CV file missing on disk")
    return FileResponse(full_path, filename=os.path.basename(full_path))


@router.get("/messages")
def get_org_messages(org_id: int, db: Session = Depends(get_db)):
    matches = db.query(Match).filter(Match.org_id == org_id).all()
    result = []
    for m in matches:
        msgs = db.query(Message).filter(Message.match_id == m.id).order_by(Message.sent_at).all()
        if msgs:
            result.append({
                "match_id": m.id,
                "student_name": m.student.name,
                "messages": [{"id": msg.id, "sender_type": msg.sender_type, "content": msg.content, "sent_at": msg.sent_at.isoformat()} for msg in msgs],
            })
    return result
