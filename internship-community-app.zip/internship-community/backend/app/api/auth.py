from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.models.database import get_db, OrgContact
from app.schemas.schemas import LoginRequest

router = APIRouter(prefix="/api/auth", tags=["auth"])

ADMIN_EMAIL = "admin@community.com"
ADMIN_PASSWORD = "admin123"


@router.post("/login")
def login(payload: LoginRequest, db: Session = Depends(get_db)):
    if payload.email == ADMIN_EMAIL and payload.password == ADMIN_PASSWORD:
        return {"role": "admin", "email": ADMIN_EMAIL, "name": "Admin"}

    contact = db.query(OrgContact).filter(OrgContact.email == payload.email).first()
    if contact and payload.password == "password123":
        return {
            "role": "org",
            "email": contact.email,
            "name": contact.name,
            "org_id": contact.org_id,
            "org_name": contact.organization.name,
        }

    raise HTTPException(status_code=401, detail="Invalid email or password")
