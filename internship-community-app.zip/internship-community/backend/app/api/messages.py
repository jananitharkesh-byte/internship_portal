from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.models.database import get_db, Message, Match
from app.schemas.schemas import MessageCreate

router = APIRouter(prefix="/api/messages", tags=["messages"])


@router.get("/{match_id}")
def get_messages(match_id: int, db: Session = Depends(get_db)):
    msgs = db.query(Message).filter(Message.match_id == match_id).order_by(Message.sent_at).all()
    return [
        {"id": m.id, "sender_type": m.sender_type, "content": m.content, "sent_at": m.sent_at.isoformat()}
        for m in msgs
    ]


@router.post("/")
def send_message(payload: MessageCreate, db: Session = Depends(get_db)):
    match = db.query(Match).get(payload.match_id)
    if not match:
        raise HTTPException(status_code=404, detail="Match not found")
    if payload.sender_type not in ("org", "student"):
        raise HTTPException(status_code=400, detail="sender_type must be 'org' or 'student'")

    msg = Message(match_id=payload.match_id, sender_type=payload.sender_type, content=payload.content)
    db.add(msg)
    db.commit()
    db.refresh(msg)
    return {"id": msg.id, "sender_type": msg.sender_type, "content": msg.content, "sent_at": msg.sent_at.isoformat()}
