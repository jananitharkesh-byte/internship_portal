import React, { useEffect, useState, useMemo } from 'react'
import { motion } from 'framer-motion'
import { Send, Filter } from 'lucide-react'
import toast from 'react-hot-toast'
import Navbar from '../../components/Common/Navbar.jsx'
import api from '../../api/client.js'

const NAV_LINKS = [
  { to: '/admin/dashboard', label: 'Dashboard' },
  { to: '/admin/upload', label: 'Upload' },
  { to: '/admin/matches', label: 'Matches' },
  { to: '/admin/students', label: 'Students' },
]

function scoreColor(score) {
  if (score >= 80) return 'text-emerald-400 bg-emerald-400/10'
  if (score >= 60) return 'text-amber-400 bg-amber-400/10'
  return 'text-rose-400 bg-rose-400/10'
}

export default function AdminMatches() {
  const [matches, setMatches] = useState([])
  const [selected, setSelected] = useState(new Set())
  const [statusFilter, setStatusFilter] = useState('')
  const [minScore, setMinScore] = useState(0)
  const [loading, setLoading] = useState(true)

  const load = () => {
    setLoading(true)
    const params = {}
    if (statusFilter) params.status = statusFilter
    if (minScore) params.min_score = minScore
    api.get('/admin/matches', { params }).then((res) => {
      setMatches(res.data)
      setLoading(false)
    })
  }

  useEffect(load, [statusFilter, minScore])

  const toggle = (id) => {
    setSelected((prev) => {
      const next = new Set(prev)
      next.has(id) ? next.delete(id) : next.add(id)
      return next
    })
  }

  const sendSelected = async () => {
    if (selected.size === 0) return
    try {
      const { data } = await api.post('/admin/matches/send', { match_ids: Array.from(selected) })
      toast.success(`Sent ${data.sent} matches to ${data.organizations_notified} organizations`)
      setSelected(new Set())
      load()
    } catch {
      toast.error('Failed to send matches')
    }
  }

  const grouped = useMemo(() => matches, [matches])

  return (
    <div>
      <Navbar links={NAV_LINKS} />
      <div className="max-w-7xl mx-auto px-6 py-8">
        <div className="flex flex-wrap items-center justify-between gap-4 mb-6">
          <div>
            <h1 className="text-2xl font-bold text-white tracking-tight">Match Management</h1>
            <p className="text-slate-400 text-sm mt-1">{matches.length} matches found</p>
          </div>
          <motion.button
            whileTap={{ scale: 0.97 }}
            onClick={sendSelected}
            disabled={selected.size === 0}
            className="btn-gradient rounded-lg px-4 py-2.5 text-white text-sm font-medium flex items-center gap-2 disabled:opacity-40"
          >
            <Send size={15} /> Send {selected.size > 0 ? `(${selected.size})` : ''}
          </motion.button>
        </div>

        <div className="glass rounded-2xl p-4 mb-6 flex flex-wrap items-center gap-3">
          <Filter size={15} className="text-slate-500" />
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="bg-navy-950/60 border border-white/10 rounded-lg px-3 py-1.5 text-sm text-white outline-none"
          >
            <option value="">All statuses</option>
            <option value="pending">Pending</option>
            <option value="sent">Sent</option>
            <option value="accepted">Accepted</option>
            <option value="rejected">Rejected</option>
          </select>
          <select
            value={minScore}
            onChange={(e) => setMinScore(Number(e.target.value))}
            className="bg-navy-950/60 border border-white/10 rounded-lg px-3 py-1.5 text-sm text-white outline-none"
          >
            <option value={0}>Any score</option>
            <option value={60}>60%+</option>
            <option value={80}>80%+</option>
          </select>
        </div>

        <div className="glass rounded-2xl overflow-hidden">
          <div className="grid grid-cols-[auto_1fr_1fr_auto_auto] gap-4 px-5 py-3 text-xs text-slate-500 uppercase tracking-wide border-b border-white/5">
            <span></span>
            <span>Student</span>
            <span>Organization</span>
            <span>Score</span>
            <span>Status</span>
          </div>
          {loading ? (
            <div className="p-10 text-center text-slate-500 text-sm">Loading matches…</div>
          ) : (
            grouped.map((m) => (
              <motion.div
                key={m.id}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="grid grid-cols-[auto_1fr_1fr_auto_auto] gap-4 px-5 py-3 items-center border-b border-white/5 last:border-0 hover:bg-white/[0.02]"
              >
                <input
                  type="checkbox"
                  checked={selected.has(m.id)}
                  onChange={() => toggle(m.id)}
                  className="accent-accent-500"
                />
                <div>
                  <p className="text-white text-sm font-medium">{m.student.name}</p>
                  <p className="text-slate-500 text-xs">{m.student.domain}</p>
                </div>
                <div>
                  <p className="text-slate-300 text-sm">{m.organization.name}</p>
                  <p className="text-slate-500 text-xs">{m.organization.industry}</p>
                </div>
                <span className={`text-xs font-semibold px-2.5 py-1 rounded-full mono ${scoreColor(m.match_score)}`}>
                  {m.match_score}%
                </span>
                <span className="text-xs text-slate-400 capitalize">{m.status}</span>
              </motion.div>
            ))
          )}
        </div>
      </div>
    </div>
  )
}
