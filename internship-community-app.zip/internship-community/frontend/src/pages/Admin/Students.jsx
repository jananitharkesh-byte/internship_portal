import React, { useEffect, useState } from 'react'
import { motion } from 'framer-motion'
import { Trash2 } from 'lucide-react'
import toast from 'react-hot-toast'
import Navbar from '../../components/Common/Navbar.jsx'
import api from '../../api/client.js'

const NAV_LINKS = [
  { to: '/admin/dashboard', label: 'Dashboard' },
  { to: '/admin/upload', label: 'Upload' },
  { to: '/admin/matches', label: 'Matches' },
  { to: '/admin/students', label: 'Students' },
]

export default function AdminStudents() {
  const [students, setStudents] = useState([])
  const [loading, setLoading] = useState(true)

  const load = () => {
    setLoading(true)
    api.get('/admin/students').then((res) => {
      setStudents(res.data)
      setLoading(false)
    })
  }

  useEffect(load, [])

  const remove = async (id) => {
    try {
      await api.delete(`/admin/students/${id}`)
      toast.success('Student removed')
      load()
    } catch {
      toast.error('Failed to remove student')
    }
  }

  return (
    <div>
      <Navbar links={NAV_LINKS} />
      <div className="max-w-7xl mx-auto px-6 py-8">
        <h1 className="text-2xl font-bold text-white tracking-tight mb-1">Students</h1>
        <p className="text-slate-400 text-sm mb-6">{students.length} records</p>

        <div className="glass rounded-2xl overflow-hidden">
          <div className="grid grid-cols-[1fr_1fr_1fr_auto] gap-4 px-5 py-3 text-xs text-slate-500 uppercase tracking-wide border-b border-white/5">
            <span>Name</span>
            <span>Skills</span>
            <span>Domain / Dept</span>
            <span></span>
          </div>
          {loading ? (
            <div className="p-10 text-center text-slate-500 text-sm">Loading students…</div>
          ) : (
            students.map((s) => (
              <motion.div
                key={s.id}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="grid grid-cols-[1fr_1fr_1fr_auto] gap-4 px-5 py-3 items-center border-b border-white/5 last:border-0 hover:bg-white/[0.02]"
              >
                <div>
                  <p className="text-white text-sm font-medium">{s.name}</p>
                  <p className="text-slate-500 text-xs">{s.email}</p>
                </div>
                <p className="text-slate-400 text-xs truncate">{s.skills}</p>
                <p className="text-slate-400 text-xs">{s.domain} · {s.dept_preference}</p>
                <button
                  onClick={() => remove(s.id)}
                  className="p-2 rounded-lg text-slate-500 hover:text-rose-400 hover:bg-rose-400/10 transition-colors"
                  aria-label={`Remove ${s.name}`}
                >
                  <Trash2 size={15} />
                </button>
              </motion.div>
            ))
          )}
        </div>
      </div>
    </div>
  )
}
