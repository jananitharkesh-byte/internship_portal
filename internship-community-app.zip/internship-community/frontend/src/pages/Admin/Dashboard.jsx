import React, { useEffect, useState } from 'react'
import { motion } from 'framer-motion'
import { Users, Building2, GitMerge, Clock } from 'lucide-react'
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, Legend } from 'recharts'
import Navbar from '../../components/Common/Navbar.jsx'
import StatCard from '../../components/ui/StatCard.jsx'
import api from '../../api/client.js'

const NAV_LINKS = [
  { to: '/admin/dashboard', label: 'Dashboard' },
  { to: '/admin/upload', label: 'Upload' },
  { to: '/admin/matches', label: 'Matches' },
  { to: '/admin/students', label: 'Students' },
]

const COLORS = ['#3b82f6', '#60a5fa', '#1e3153']

export default function AdminDashboard() {
  const [stats, setStats] = useState(null)

  useEffect(() => {
    api.get('/admin/dashboard').then((res) => setStats(res.data))
  }, [])

  const chartData = stats
    ? [
        { name: 'High (80%+)', value: stats.match_distribution.high },
        { name: 'Medium (60-79%)', value: stats.match_distribution.medium },
        { name: 'Low (<60%)', value: stats.match_distribution.low },
      ]
    : []

  return (
    <div>
      <Navbar links={NAV_LINKS} />
      <div className="max-w-7xl mx-auto px-6 py-8">
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="mb-8">
          <h1 className="text-2xl font-bold text-white tracking-tight">Dashboard</h1>
          <p className="text-slate-400 text-sm mt-1">Live overview of the matching pipeline</p>
        </motion.div>

        {stats ? (
          <>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
              <StatCard icon={Users} label="Total Students" value={stats.total_students} delay={0} />
              <StatCard icon={Building2} label="Total Organizations" value={stats.total_orgs} accent="text-emerald-400" delay={0.05} />
              <StatCard icon={GitMerge} label="Total Matches" value={stats.total_matches} accent="text-violet-400" delay={0.1} />
              <StatCard icon={Clock} label="Pending Actions" value={stats.pending_matches} accent="text-amber-400" delay={0.15} />
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <motion.div
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 }}
                className="glass rounded-2xl p-6 lg:col-span-1"
              >
                <h2 className="text-white font-semibold mb-4">Match Score Distribution</h2>
                <ResponsiveContainer width="100%" height={220}>
                  <PieChart>
                    <Pie data={chartData} dataKey="value" nameKey="name" innerRadius={50} outerRadius={80} paddingAngle={3}>
                      {chartData.map((_, i) => (
                        <Cell key={i} fill={COLORS[i % COLORS.length]} stroke="none" />
                      ))}
                    </Pie>
                    <Tooltip contentStyle={{ background: '#0f1f38', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 8, color: '#fff' }} />
                    <Legend wrapperStyle={{ fontSize: 12, color: '#94a3b8' }} />
                  </PieChart>
                </ResponsiveContainer>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.25 }}
                className="glass rounded-2xl p-6 lg:col-span-2"
              >
                <h2 className="text-white font-semibold mb-4">Quick Actions</h2>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <a href="/admin/upload" className="glass-hover rounded-xl p-4 border border-white/5 block">
                    <p className="text-white font-medium text-sm">Upload Students</p>
                    <p className="text-slate-500 text-xs mt-1">Import a ZIP with Excel + CVs</p>
                  </a>
                  <a href="/admin/matches" className="glass-hover rounded-xl p-4 border border-white/5 block">
                    <p className="text-white font-medium text-sm">Review Matches</p>
                    <p className="text-slate-500 text-xs mt-1">Filter, edit, and send matches</p>
                  </a>
                  <a href="/admin/students" className="glass-hover rounded-xl p-4 border border-white/5 block">
                    <p className="text-white font-medium text-sm">Manage Students</p>
                    <p className="text-slate-500 text-xs mt-1">View and remove student records</p>
                  </a>
                </div>
              </motion.div>
            </div>
          </>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {[0, 1, 2, 3].map((i) => (
              <div key={i} className="glass rounded-2xl p-5 h-28 animate-pulse" />
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
