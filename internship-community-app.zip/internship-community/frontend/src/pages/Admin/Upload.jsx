import React, { useState, useCallback } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { UploadCloud, FileArchive, CheckCircle2 } from 'lucide-react'
import toast from 'react-hot-toast'
import Navbar from '../../components/Common/Navbar.jsx'
import api from '../../api/client.js'

const NAV_LINKS = [
  { to: '/admin/dashboard', label: 'Dashboard' },
  { to: '/admin/upload', label: 'Upload' },
  { to: '/admin/matches', label: 'Matches' },
  { to: '/admin/students', label: 'Students' },
]

export default function AdminUpload() {
  const [dragOver, setDragOver] = useState(false)
  const [file, setFile] = useState(null)
  const [uploading, setUploading] = useState(false)
  const [result, setResult] = useState(null)

  const onDrop = useCallback((e) => {
    e.preventDefault()
    setDragOver(false)
    const dropped = e.dataTransfer.files?.[0]
    if (dropped) setFile(dropped)
  }, [])

  const handleUpload = async () => {
    if (!file) return
    setUploading(true)
    setResult(null)
    const formData = new FormData()
    formData.append('file', file)
    try {
      const { data } = await api.post('/admin/upload', formData, {
        headers: { 'Content-Type': 'multipart/form-data' },
      })
      setResult(data)
      toast.success(`${data.students_created} students imported`)
    } catch (err) {
      toast.error(err.response?.data?.detail || 'Upload failed')
    } finally {
      setUploading(false)
    }
  }

  return (
    <div>
      <Navbar links={NAV_LINKS} />
      <div className="max-w-3xl mx-auto px-6 py-10">
        <h1 className="text-2xl font-bold text-white tracking-tight mb-1">Upload Students</h1>
        <p className="text-slate-400 text-sm mb-8">
          Drop a ZIP containing an Excel sheet (name, email, skills, domain, dept_preference, cv_filename) and a folder of CVs.
        </p>

        <div
          onDragOver={(e) => { e.preventDefault(); setDragOver(true) }}
          onDragLeave={() => setDragOver(false)}
          onDrop={onDrop}
          className={`glass rounded-2xl border-2 border-dashed p-12 flex flex-col items-center text-center transition-colors ${
            dragOver ? 'border-accent-500 bg-accent-500/5' : 'border-white/10'
          }`}
        >
          <motion.div animate={{ y: dragOver ? -4 : 0 }} className="w-14 h-14 rounded-xl btn-gradient flex items-center justify-center mb-4">
            <UploadCloud size={26} className="text-white" />
          </motion.div>
          <p className="text-white font-medium mb-1">Drag and drop your ZIP file here</p>
          <p className="text-slate-500 text-sm mb-4">or click below to browse</p>
          <label className="cursor-pointer">
            <input type="file" accept=".zip" className="hidden" onChange={(e) => setFile(e.target.files?.[0] || null)} />
            <span className="btn-gradient px-5 py-2 rounded-lg text-white text-sm font-medium inline-block">Choose file</span>
          </label>

          {file && (
            <div className="mt-6 flex items-center gap-2 text-sm text-slate-300 bg-white/5 rounded-lg px-4 py-2">
              <FileArchive size={16} className="text-accent-400" />
              {file.name}
            </div>
          )}
        </div>

        <motion.button
          whileTap={{ scale: 0.98 }}
          disabled={!file || uploading}
          onClick={handleUpload}
          className="btn-gradient w-full mt-6 rounded-lg py-3 text-white font-medium disabled:opacity-50"
        >
          {uploading ? 'Processing upload…' : 'Upload and generate matches'}
        </motion.button>

        <AnimatePresence>
          {result && (
            <motion.div
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              className="glass rounded-2xl p-6 mt-6"
            >
              <div className="flex items-center gap-2 text-emerald-400 mb-3">
                <CheckCircle2 size={18} />
                <span className="font-medium">Import complete</span>
              </div>
              <p className="text-slate-300 text-sm mb-3">{result.students_created} students added and matched automatically.</p>
              <div className="flex flex-wrap gap-2">
                {result.names.map((n, i) => (
                  <span key={i} className="text-xs bg-white/5 text-slate-400 px-2.5 py-1 rounded-full">{n}</span>
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        <div className="mt-8 glass rounded-2xl p-5">
          <p className="text-slate-400 text-xs mono">
            Expected Excel columns: name · email · skills (comma-separated) · domain · dept_preference · cv_filename
          </p>
        </div>
      </div>
    </div>
  )
}
