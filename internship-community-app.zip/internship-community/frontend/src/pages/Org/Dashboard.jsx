import React, { useEffect, useState } from 'react'
import { motion } from 'framer-motion'
import { Users, CheckCircle2, Clock, MessageSquare } from 'lucide-react'
import Navbar from '../../components/Common/Navbar.jsx'
import StatCard from '../../components/ui/StatCard.jsx'
import api from '../../api/client.js'
import { useAuth } from '../../context/AuthContext.jsx'

const NAV_LINKS = [
  { to: '/org/dashboard', label: 'Dashboard' },
  { to: '/org/matches', label: 'Matches' },
  { to: '/org/messages', label: 'Messages' },
]

export default function OrgDashboard() {
  const { user } = useAuth()
  const [stats, setStats] = useState(null)

  useEffect(() => {
    api.get('/org/dashboard', { params: { org_id: user.org_id } }).then((res) => setStats(res.data))
  }, [])

  return (
    <div>
      <Navbar links={NAV_LINKS} />
      <div className="max-w-7xl mx-auto px-6 py-8">
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="mb-8">
          <h1 className="text-2xl font-bold text-white tracking-tight">Welcome, {stats?.org_name || user.org_name}</h1>
          <p className="text-slate-400 text-sm mt-1">Here's what's happening with your candidate matches</p>
        </motion.div>

        {stats ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <StatCard icon={Users} label="Matched Students" value={stats.matched_students} delay={0} />
            <StatCard icon={CheckCircle2} label="Accepted" value={stats.accepted} accent="text-emerald-400" delay={0.05} />
            <StatCard icon={Clock} label="Pending Review" value={stats.pending} accent="text-amber-400" delay={0.1} />
            <StatCard icon={MessageSquare} label="New Messages" value={stats.messages_count} accent="text-violet-400" delay={0.15} />
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {[0, 1, 2, 3].map((i) => (
              <div key={i} className="glass rounded-2xl p-5 h-28 animate-pulse" />
            ))}
          </div>
        )}

        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="glass rounded-2xl p-6 mt-6"
        >
          <h2 className="text-white font-semibold mb-2">Next steps</h2>
          <p className="text-slate-400 text-sm">
            Head to the <a href="/org/matches" className="text-accent-400 hover:underline">Matches</a> tab to review candidates,
            download CVs, and start conversations with students who fit your open roles.
          </p>
        </motion.div>
      </div>
    </div>
  )
}
