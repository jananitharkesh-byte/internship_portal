import React, { useEffect, useRef, useState } from 'react'
import { motion } from 'framer-motion'
import { Send } from 'lucide-react'
import { useLocation } from 'react-router-dom'
import Navbar from '../../components/Common/Navbar.jsx'
import api from '../../api/client.js'
import { useAuth } from '../../context/AuthContext.jsx'

const NAV_LINKS = [
  { to: '/org/dashboard', label: 'Dashboard' },
  { to: '/org/matches', label: 'Matches' },
  { to: '/org/messages', label: 'Messages' },
]

export default function OrgMessages() {
  const { user } = useAuth()
  const location = useLocation()
  const [matches, setMatches] = useState([])
  const [activeId, setActiveId] = useState(location.state?.matchId || null)
  const [messages, setMessages] = useState([])
  const [draft, setDraft] = useState('')
  const scrollRef = useRef(null)

  useEffect(() => {
    api.get('/org/matches', { params: { org_id: user.org_id } }).then((res) => {
      setMatches(res.data)
      if (!activeId && res.data.length > 0) setActiveId(res.data[0].id)
    })
  }, [])

  useEffect(() => {
    if (!activeId) return
    const fetchMessages = () => {
      api.get(`/messages/${activeId}`).then((res) => setMessages(res.data))
    }
    fetchMessages()
    const interval = setInterval(fetchMessages, 3000) // polling for prototype
    return () => clearInterval(interval)
  }, [activeId])

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: 'smooth' })
  }, [messages])

  const send = async () => {
    if (!draft.trim() || !activeId) return
    const content = draft
    setDraft('')
    await api.post('/messages/', { match_id: activeId, sender_type: 'org', content })
    api.get(`/messages/${activeId}`).then((res) => setMessages(res.data))
  }

  const activeMatch = matches.find((m) => m.id === activeId)

  return (
    <div>
      <Navbar links={NAV_LINKS} />
      <div className="max-w-7xl mx-auto px-6 py-8">
        <h1 className="text-2xl font-bold text-white tracking-tight mb-6">Messages</h1>

        <div className="glass rounded-2xl flex h-[560px] overflow-hidden">
          <div className="w-64 border-r border-white/5 overflow-y-auto">
            {matches.map((m) => (
              <button
                key={m.id}
                onClick={() => setActiveId(m.id)}
                className={`w-full text-left px-4 py-3 border-b border-white/5 transition-colors ${
                  activeId === m.id ? 'bg-accent-500/10' : 'hover:bg-white/[0.02]'
                }`}
              >
                <p className="text-white text-sm font-medium">{m.student.name}</p>
                <p className="text-slate-500 text-xs">{m.student.domain}</p>
              </button>
            ))}
          </div>

          <div className="flex-1 flex flex-col">
            {activeMatch ? (
              <>
                <div className="px-5 py-3 border-b border-white/5">
                  <p className="text-white text-sm font-medium">{activeMatch.student.name}</p>
                  <p className="text-slate-500 text-xs">{activeMatch.match_score}% match</p>
                </div>
                <div ref={scrollRef} className="flex-1 overflow-y-auto px-5 py-4 space-y-3">
                  {messages.length === 0 && (
                    <p className="text-slate-500 text-sm text-center mt-10">No messages yet — say hello 👋</p>
                  )}
                  {messages.map((msg) => (
                    <motion.div
                      key={msg.id}
                      initial={{ opacity: 0, y: 6 }}
                      animate={{ opacity: 1, y: 0 }}
                      className={`max-w-[70%] px-4 py-2 rounded-2xl text-sm ${
                        msg.sender_type === 'org'
                          ? 'ml-auto bg-accent-500/20 text-white rounded-br-sm'
                          : 'bg-white/5 text-slate-200 rounded-bl-sm'
                      }`}
                    >
                      {msg.content}
                    </motion.div>
                  ))}
                </div>
                <div className="p-4 border-t border-white/5 flex gap-2">
                  <input
                    value={draft}
                    onChange={(e) => setDraft(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && send()}
                    placeholder="Type a message…"
                    className="flex-1 bg-navy-950/60 border border-white/10 rounded-lg px-4 py-2 text-sm text-white placeholder-slate-600 outline-none focus:border-accent-500"
                  />
                  <button onClick={send} className="btn-gradient px-4 rounded-lg text-white" aria-label="Send message">
                    <Send size={16} />
                  </button>
                </div>
              </>
            ) : (
              <div className="flex-1 flex items-center justify-center text-slate-500 text-sm">
                Select a candidate to start messaging
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
