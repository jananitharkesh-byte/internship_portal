import React, { useEffect, useState } from 'react'
import { motion } from 'framer-motion'
import { Download, MessageSquare, ThumbsUp, ThumbsDown } from 'lucide-react'
import toast from 'react-hot-toast'
import { useNavigate } from 'react-router-dom'
import Navbar from '../../components/Common/Navbar.jsx'
import api from '../../api/client.js'
import { useAuth } from '../../context/AuthContext.jsx'

const NAV_LINKS = [
  { to: '/org/dashboard', label: 'Dashboard' },
  { to: '/org/matches', label: 'Matches' },
  { to: '/org/messages', label: 'Messages' },
]

function scoreColor(score) {
  if (score >= 80) return 'text-emerald-400 border-emerald-400/30'
  if (score >= 60) return 'text-amber-400 border-amber-400/30'
  return 'text-rose-400 border-rose-400/30'
}

export default function OrgMatches() {
  const { user } = useAuth()
  const [matches, setMatches] = useState([])
  const [loading, setLoading] = useState(true)
  const navigate = useNavigate()

  const load = () => {
    setLoading(true)
    api.get('/org/matches', { params: { org_id: user.org_id } }).then((res) => {
      setMatches(res.data)
      setLoading(false)
    })
  }

  useEffect(load, [])

  const updateStatus = async (matchId, status) => {
    try {
      await api.put(`/org/matches/${matchId}/status`, null, { params: { status } })
      toast.success(status === 'accepted' ? 'Candidate accepted' : 'Candidate declined')
      load()
    } catch {
      toast.error('Failed to update status')
    }
  }

  const downloadCV = (studentId) => {
    window.open(`/api/org/students/${studentId}/cv`, '_blank')
  }

  return (
    <div>
      <Navbar links={NAV_LINKS} />
      <div className="max-w-7xl mx-auto px-6 py-8">
        <h1 className="text-2xl font-bold text-white tracking-tight mb-1">Your Matches</h1>
        <p className="text-slate-400 text-sm mb-6">{matches.length} candidates matched to your open roles</p>

        {loading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {[0, 1, 2, 3, 4, 5].map((i) => <div key={i} className="glass rounded-2xl h-48 animate-pulse" />)}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {matches.map((m, i) => (
              <motion.div
                key={m.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.03 }}
                className="glass glass-hover rounded-2xl p-5 flex flex-col"
              >
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-full bg-accent-500/15 text-accent-400 flex items-center justify-center text-sm font-semibold">
                      {m.student.name.split(' ').map((n) => n[0]).join('').slice(0, 2)}
                    </div>
                    <div>
                      <p className="text-white text-sm font-medium">{m.student.name}</p>
                      <p className="text-slate-500 text-xs">{m.student.domain}</p>
                    </div>
                  </div>
                  <span className={`text-xs font-semibold px-2 py-1 rounded-full border mono ${scoreColor(m.match_score)}`}>
                    {m.match_score}%
                  </span>
                </div>

                <p className="text-slate-400 text-xs mb-4 line-clamp-2">{m.student.skills}</p>

                <span className="text-xs text-slate-500 mb-4 capitalize">Status: {m.status}</span>

                <div className="mt-auto flex items-center gap-2 pt-3 border-t border-white/5">
                  <button
                    onClick={() => downloadCV(m.student.id)}
                    className="flex-1 text-xs flex items-center justify-center gap-1.5 py-2 rounded-lg bg-white/5 hover:bg-white/10 text-slate-300 transition-colors"
                  >
                    <Download size={13} /> CV
                  </button>
                  <button
                    onClick={() => navigate('/org/messages', { state: { matchId: m.id } })}
                    className="flex-1 text-xs flex items-center justify-center gap-1.5 py-2 rounded-lg bg-white/5 hover:bg-white/10 text-slate-300 transition-colors"
                  >
                    <MessageSquare size={13} /> Message
                  </button>
                  <button
                    onClick={() => updateStatus(m.id, 'accepted')}
                    className="p-2 rounded-lg bg-emerald-400/10 text-emerald-400 hover:bg-emerald-400/20 transition-colors"
                    aria-label="Accept"
                  >
                    <ThumbsUp size={13} />
                  </button>
                  <button
                    onClick={() => updateStatus(m.id, 'rejected')}
                    className="p-2 rounded-lg bg-rose-400/10 text-rose-400 hover:bg-rose-400/20 transition-colors"
                    aria-label="Reject"
                  >
                    <ThumbsDown size={13} />
                  </button>
                </div>
              </motion.div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
