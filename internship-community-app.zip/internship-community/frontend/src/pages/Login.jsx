import React, { useState } from 'react'
import { motion } from 'framer-motion'
import { useNavigate } from 'react-router-dom'
import toast from 'react-hot-toast'
import { Radar, ArrowRight } from 'lucide-react'
import api from '../api/client.js'
import { useAuth } from '../context/AuthContext.jsx'

export default function Login() {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [loading, setLoading] = useState(false)
  const navigate = useNavigate()
  const { login } = useAuth()

  const handleSubmit = async (e) => {
    e.preventDefault()
    setLoading(true)
    try {
      const { data } = await api.post('/auth/login', { email, password })
      login(data)
      toast.success(`Welcome back, ${data.name}`)
      navigate(data.role === 'admin' ? '/admin/dashboard' : '/org/dashboard')
    } catch (err) {
      toast.error(err.response?.data?.detail || 'Login failed')
    } finally {
      setLoading(false)
    }
  }

  const fillDemo = (type) => {
    if (type === 'admin') {
      setEmail('admin@community.com')
      setPassword('admin123')
    } else {
      setEmail('techcorp@org.com')
      setPassword('password123')
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center px-6">
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
        className="w-full max-w-md"
      >
        <div className="flex flex-col items-center mb-8">
          <div className="w-12 h-12 rounded-xl btn-gradient flex items-center justify-center mb-4">
            <Radar size={24} className="text-white" />
          </div>
          <h1 className="text-2xl font-bold text-white tracking-tight">Internship Community</h1>
          <p className="text-slate-400 text-sm mt-1">Matching platform portal</p>
        </div>

        <form onSubmit={handleSubmit} className="glass rounded-2xl p-8 space-y-4">
          <div>
            <label className="text-sm text-slate-400 mb-1.5 block">Email</label>
            <input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="you@organization.com"
              className="w-full bg-navy-950/60 border border-white/10 rounded-lg px-4 py-2.5 text-white placeholder-slate-600 focus:border-accent-500 outline-none transition-colors"
            />
          </div>
          <div>
            <label className="text-sm text-slate-400 mb-1.5 block">Password</label>
            <input
              type="password"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
              className="w-full bg-navy-950/60 border border-white/10 rounded-lg px-4 py-2.5 text-white placeholder-slate-600 focus:border-accent-500 outline-none transition-colors"
            />
          </div>

          <motion.button
            whileTap={{ scale: 0.98 }}
            type="submit"
            disabled={loading}
            className="btn-gradient w-full rounded-lg py-2.5 text-white font-medium flex items-center justify-center gap-2 disabled:opacity-60"
          >
            {loading ? 'Signing in…' : 'Sign in'}
            {!loading && <ArrowRight size={16} />}
          </motion.button>

          <div className="pt-4 border-t border-white/5 flex flex-col gap-2">
            <p className="text-xs text-slate-500 text-center">Quick demo access</p>
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => fillDemo('admin')}
                className="flex-1 text-xs py-2 rounded-lg bg-white/5 hover:bg-white/10 text-slate-300 transition-colors"
              >
                Fill admin login
              </button>
              <button
                type="button"
                onClick={() => fillDemo('org')}
                className="flex-1 text-xs py-2 rounded-lg bg-white/5 hover:bg-white/10 text-slate-300 transition-colors"
              >
                Fill org login
              </button>
            </div>
            <p className="text-xs text-slate-600 text-center mono">any org email + password123</p>
          </div>
        </form>
      </motion.div>
    </div>
  )
}
