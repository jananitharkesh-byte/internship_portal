import React, { useEffect, useState } from 'react'
import { motion } from 'framer-motion'

function useCountUp(target, duration = 900) {
  const [value, setValue] = useState(0)
  useEffect(() => {
    let start = null
    const step = (ts) => {
      if (!start) start = ts
      const progress = Math.min((ts - start) / duration, 1)
      setValue(Math.floor(progress * target))
      if (progress < 1) requestAnimationFrame(step)
    }
    requestAnimationFrame(step)
  }, [target, duration])
  return value
}

export default function StatCard({ icon: Icon, label, value, accent = 'text-accent-400', delay = 0 }) {
  const animated = useCountUp(typeof value === 'number' ? value : 0)
  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay, duration: 0.35 }}
      className="glass glass-hover rounded-2xl p-5"
    >
      <div className="flex items-center justify-between mb-3">
        <span className="text-sm text-slate-400">{label}</span>
        {Icon && <Icon size={18} className={accent} />}
      </div>
      <p className={`text-3xl font-bold mono ${accent}`}>
        {typeof value === 'number' ? animated : value}
      </p>
    </motion.div>
  )
}
