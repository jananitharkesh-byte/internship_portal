import React from 'react'
import { Routes, Route, Navigate } from 'react-router-dom'
import { Toaster } from 'react-hot-toast'
import { AuthProvider } from './context/AuthContext.jsx'
import ProtectedRoute from './components/Common/ProtectedRoute.jsx'

import Login from './pages/Login.jsx'
import AdminDashboard from './pages/Admin/Dashboard.jsx'
import AdminUpload from './pages/Admin/Upload.jsx'
import AdminMatches from './pages/Admin/Matches.jsx'
import AdminStudents from './pages/Admin/Students.jsx'
import OrgDashboard from './pages/Org/Dashboard.jsx'
import OrgMatches from './pages/Org/Matches.jsx'
import OrgMessages from './pages/Org/Messages.jsx'

export default function App() {
  return (
    <AuthProvider>
      <Toaster
        position="top-right"
        toastOptions={{
          style: { background: '#0f1f38', color: '#e6ecf7', border: '1px solid rgba(255,255,255,0.08)' },
        }}
      />
      <Routes>
        <Route path="/login" element={<Login />} />

        <Route path="/admin/dashboard" element={<ProtectedRoute role="admin"><AdminDashboard /></ProtectedRoute>} />
        <Route path="/admin/upload" element={<ProtectedRoute role="admin"><AdminUpload /></ProtectedRoute>} />
        <Route path="/admin/matches" element={<ProtectedRoute role="admin"><AdminMatches /></ProtectedRoute>} />
        <Route path="/admin/students" element={<ProtectedRoute role="admin"><AdminStudents /></ProtectedRoute>} />

        <Route path="/org/dashboard" element={<ProtectedRoute role="org"><OrgDashboard /></ProtectedRoute>} />
        <Route path="/org/matches" element={<ProtectedRoute role="org"><OrgMatches /></ProtectedRoute>} />
        <Route path="/org/messages" element={<ProtectedRoute role="org"><OrgMessages /></ProtectedRoute>} />

        <Route path="*" element={<Navigate to="/login" replace />} />
      </Routes>
    </AuthProvider>
  )
}
