# Internship Community Matching Platform

A full-stack prototype that matches students to organizations based on skills, domain, and department, then lets org contacts review matches, download CVs, and message candidates directly.

- **Backend:** FastAPI + SQLite (SQLAlchemy)
- **Frontend:** React + Vite + Tailwind CSS + Framer Motion
- **Data:** Auto-seeds 60 organizations and 55 students with pre-computed matches on first run

## Setup

### 1. Backend

```bash
cd backend
pip install -r requirements.txt
python -m uvicorn app.main:app --reload
```

Runs on `http://localhost:8000`. The database (`community.db`) and seed data (60 orgs, 55 students, ~440 matches) are created automatically on first startup — you'll see a `[startup] {...}` log line confirming it.

### 2. Frontend

In a second terminal:

```bash
cd frontend
npm install
npm run dev
```

Runs on `http://localhost:3000` and proxies `/api` and `/uploads` requests to the backend.

### 3. Log in

Visit `http://localhost:3000`. Use the "Fill admin login" / "Fill org login" buttons on the login screen, or:

- **Admin:** `admin@community.com` / `admin123`
- **Any organization:** any seeded org contact email / `password123`
  (open the browser console after an admin `/api/admin/matches` call, or check `community.db`, to find real seeded contact emails — or just click "Fill org login" to test with a representative account)

## Quick test flow

1. Log in as admin → **Dashboard** shows live stats and a match-score distribution chart.
2. **Upload** page → drag a ZIP containing an Excel file (`name, email, skills, domain, dept_preference, cv_filename` columns) and a folder of CVs. New students are matched automatically.
3. **Matches** page → filter by status/score, select rows, click **Send** to "email" (console-logged) the selected matches to their organizations.
4. Log out, log in as an organization contact → **Matches** tab shows that org's candidates with color-coded scores, CV download, accept/reject, and a **Message** shortcut.
5. **Messages** tab → threaded chat per candidate (polls every 3s for new messages — a stand-in for real-time updates in this prototype).

## Re-seeding

To wipe and regenerate demo data at any time:

```bash
curl -X POST http://localhost:8000/api/admin/seed
```

## Notes on this prototype

- Auth is intentionally simple (no hashing/JWT) — this is a prototype, not production-ready.
- Email sending is console-logged only; `app/services/email_service.py` is structured so swapping in SendGrid later is a small change.
- Messaging uses polling, not websockets, to keep the stack simple.
- CVs uploaded during seeding are plain-text placeholders; real PDFs work fine through the admin upload flow.
