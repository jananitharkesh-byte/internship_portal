const { contextBridge } = require('electron');

// The app itself doesn't need any Node/Electron APIs today (it just uses
// localStorage), but this bridge is here so you can safely add features
// later (e.g. native file save, printing) without turning on nodeIntegration.
contextBridge.exposeInMainWorld('electronAPI', {
  isElectron: true,
  platform: process.platform,
  versions: {
    node: process.versions.node,
    chrome: process.versions.chrome,
    electron: process.versions.electron,
  },
});
